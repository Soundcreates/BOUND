// packages/contracts/frontend.js
var FRONTEND_K = 3;
var FRONTEND_MATURITY_MS = 36e5;
var FRONTEND_REPORT_WINDOW_MS = 1728e5;
var FRONTEND_MAX_ROWS = 128;
var exact = (v, keys) => v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every((k) => Object.hasOwn(v, k));
var timestamp = (s) => {
  if (typeof s !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(s)) return false;
  const n = Date.parse(s);
  if (!Number.isFinite(n)) return false;
  const canonical = new Date(n).toISOString();
  return s === canonical || s === canonical.replace(".000Z", "Z");
};
function isFrontendPath(value) {
  if (typeof value !== "string" || !value.startsWith("/") || value.length > 256 || /[^\x20-\x7e]|[?#\\]|%(?:2f|5c)/i.test(value)) return false;
  try {
    if (new URL(value, "https://example.invalid").pathname !== value || value.startsWith("//")) return false;
    return value.split("/").every((segment) => {
      const decoded = decodeURIComponent(segment);
      return decoded.length <= 64 && !/[\x00-\x1f\x7f]/.test(decoded) && !/(?:0x)?[0-9a-f]{40}/i.test(decoded);
    });
  } catch {
    return false;
  }
}
function isFrontendHash(value) {
  if (typeof value !== "string" || !/^sha256-[A-Za-z0-9+/]{43}=$/.test(value)) return false;
  try {
    const raw = atob(value.slice(7));
    return raw.length === 32 && btoa(raw) === value.slice(7);
  } catch {
    return false;
  }
}
function validateFrontendRecord(v) {
  try {
    if (!exact(v, ["schemaVersion", "kind", "site", "chainId", "scripts", "updatedAt"]) || v.schemaVersion !== 1 || v.kind !== "frontend" || typeof v.site !== "string" || !v.site || v.site.length > 253 || !Number.isSafeInteger(v.chainId) || v.chainId <= 0 || !timestamp(v.updatedAt) || !Array.isArray(v.scripts) || v.scripts.length > FRONTEND_MAX_ROWS || new TextEncoder().encode(JSON.stringify(v)).length > 61440) return false;
    const url = new URL("https://" + v.site);
    if (url.host !== v.site || url.pathname !== "/" || url.username || url.password || url.search || url.hash) return false;
    const updated = Date.parse(v.updatedAt);
    return v.scripts.every((row, i) => {
      if (!exact(row, ["path", "hash", "reporters", "firstSeen", "lastSeen", "established"]) || !isFrontendPath(row.path) || !isFrontendHash(row.hash) || !Number.isSafeInteger(row.reporters) || row.reporters < 2 || !timestamp(row.firstSeen) || !timestamp(row.lastSeen) || typeof row.established !== "boolean") return false;
      const first = Date.parse(row.firstSeen), last = Date.parse(row.lastSeen);
      const prev = v.scripts[i - 1];
      return first <= last && last <= updated && updated - last < FRONTEND_REPORT_WINDOW_MS && row.established === (row.reporters >= FRONTEND_K && updated - first >= FRONTEND_MATURITY_MS) && (!prev || prev.path < row.path || prev.path === row.path && prev.hash < row.hash);
    });
  } catch {
    return false;
  }
}

// packages/contracts/index.js
var ADDRESS_RE = /^0x[0-9a-f]{40}$/;
var DIGEST_RE = /^0x[0-9a-f]{64}$/;
var ARKIV_ENTITY_REFERENCE_RE = /^[0-9a-f]{64}$/;
var integer = (n) => Number.isSafeInteger(n) && n >= 0;
var wellFormed = (s) => {
  for (let i = 0; i < s.length; i++) {
    const unit = s.charCodeAt(i);
    if (unit >= 55296 && unit <= 56319) {
      const next = s.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343)) return false;
    } else if (unit >= 56320 && unit <= 57343) return false;
  }
  return true;
};
var nonempty = (s) => typeof s === "string" && s.length > 0 && wellFormed(s);
var isAddress = (v) => typeof v === "string" && ADDRESS_RE.test(v);
var isDigest = (v) => typeof v === "string" && DIGEST_RE.test(v);
var isArkivEntityReference = (v) => typeof v === "string" && ARKIV_ENTITY_REFERENCE_RE.test(v);
var exact2 = (v, keys) => v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every((k) => Object.hasOwn(v, k));
var host = (s) => {
  if (!nonempty(s)) return false;
  try {
    const u = new URL("https://" + s);
    return u.host === s && u.pathname === "/" && !u.username && !u.password && !u.search && !u.hash;
  } catch {
    return false;
  }
};
var network = (v) => typeof v === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/.test(v);
var timestamp2 = (s) => {
  if (typeof s !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(s)) return false;
  const date = new Date(s);
  if (Number.isNaN(date.getTime())) return false;
  const canonical = date.toISOString();
  return s === canonical || s === canonical.replace(".000Z", "Z");
};
var sortedUnique = (xs, predicate) => Array.isArray(xs) && xs.every((x, i) => predicate(x) && (i === 0 || xs[i - 1] < x));
var addresses = (xs) => sortedUnique(xs, isAddress);
var READ_ONLY_METHODS = Object.freeze(["eth_accounts", "eth_chainId", "eth_blockNumber", "eth_call", "eth_getBalance", "eth_getCode", "eth_getTransactionCount", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockByNumber", "eth_getBlockByHash", "eth_getLogs", "net_version"]);
var ALREADY_SIGNED_METHODS = Object.freeze(["eth_sendRawTransaction"]);
var ENS_CACHE_KEYS = Object.freeze(["bound.attest.v1", "bound.frontend.v1"]);
var ENS_CACHE_VALUE_MAX = 16384;
var ensName = (s) => nonempty(s) && s.length <= 255 && /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(s);
var baseRecord = (v, keys) => exact2(v, ["schemaVersion", "kind", "site", "chainId", ...keys]) && v.schemaVersion === 1 && host(v.site) && integer(v.chainId) && v.chainId > 0;
var change = (v) => exact2(v, ["kind", "before", "after"]) && ["ns", "cert", "a-record"].includes(v.kind) && sortedUnique(v.before, nonempty) && v.before.length > 0 && sortedUnique(v.after, nonempty) && v.after.length > 0 && JSON.stringify(v.before) !== JSON.stringify(v.after);
function validateRecord(v) {
  if (v === null || typeof v !== "object" || Array.isArray(v)) return false;
  switch (v.kind) {
    case "frontend":
      return validateFrontendRecord(v);
    case "observation":
      return baseRecord(v, ["value", "reporterKey", "event"]) && isAddress(v.value) && nonempty(v.reporterKey) && ["counterparty", "called-contract", "warned"].includes(v.event);
    case "baseline":
      return baseRecord(v, ["counterparties", "calledContracts", "updatedAt"]) && addresses(v.counterparties) && addresses(v.calledContracts) && timestamp2(v.updatedAt);
    case "drift":
      return baseRecord(v, ["changes", "corroborated", "evidenceReference", "detectedAt"]) && Array.isArray(v.changes) && v.changes.length > 0 && v.changes.every((item, i) => change(item) && (!i || v.changes[i - 1].kind < item.kind)) && typeof v.corroborated === "boolean" && isArkivEntityReference(v.evidenceReference) && timestamp2(v.detectedAt);
    case "incident": {
      const isReportRef = baseRecord(v, ["trigger", "severity", "counterparty", "reportDigest", "reportReference", "createdAt"]) && typeof v.reportReference === "string" && /^[0-9a-f]{64}$/.test(v.reportReference);
      const isSwarmRef = baseRecord(v, ["trigger", "severity", "counterparty", "reportDigest", "swarmReference", "createdAt"]) && typeof v.swarmReference === "string" && /^[0-9a-f]{64}$/.test(v.swarmReference);
      return (isReportRef || isSwarmRef) && ["drift+warned", "K-same-counterparty-warned"].includes(v.trigger) && v.severity === "high" && isAddress(v.counterparty) && isDigest(v.reportDigest) && timestamp2(v.createdAt);
    }
    case "evidence":
      return baseRecord(v, ["digest", "payload", "createdAt"]) && isDigest(v.digest) && typeof v.payload === "string" && v.payload.length > 0 && new TextEncoder().encode(v.payload).length <= 61440 && timestamp2(v.createdAt);
    case "trust_snapshot":
      return exact2(v, ["schemaVersion", "kind", "network", "epoch", "digest", "canonical"]) && v.schemaVersion === 1 && network(v.network) && integer(v.epoch) && v.epoch > 0 && isDigest(v.digest) && typeof v.canonical === "string" && v.canonical.length > 0 && new TextEncoder().encode(v.canonical).length <= 61440;
    case "status":
      return baseRecord(v, ["state", "feedReference", "incidentReference", "updatedAt"]) && ["normal", "drift", "incident"].includes(v.state) && isDigest(v.feedReference) && (v.state === "incident" ? v.incidentReference === null || isDigest(v.incidentReference) : v.incidentReference === null) && timestamp2(v.updatedAt);
    // Watcher-asserted copy of ENS text records for one curated site. It is a
    // cache for availability and display only; it never establishes trust.
    case "ens_record":
      return baseRecord(v, ["name", "resolver", "records", "resolvedAt"]) && ensName(v.name) && isAddress(v.resolver) && timestamp2(v.resolvedAt) && v.records !== null && typeof v.records === "object" && !Array.isArray(v.records) && Object.keys(v.records).length > 0 && Object.entries(v.records).every(([k, text]) => ENS_CACHE_KEYS.includes(k) && typeof text === "string" && text.length <= ENS_CACHE_VALUE_MAX && wellFormed(text));
    default:
      return false;
  }
}
function parseUniqueJSON(text) {
  if (typeof text !== "string" || text.length > 1e6) throw new Error("invalid JSON size");
  const value = JSON.parse(text);
  let i = 0;
  const ws = () => {
    while (i < text.length && /\s/.test(text[i])) i++;
  };
  const str = () => {
    const start = i++;
    while (i < text.length) {
      if (text[i] === "\\") {
        i += 2;
        continue;
      }
      if (text[i++] === '"') {
        const value2 = JSON.parse(text.slice(start, i));
        if (!wellFormed(value2)) throw new Error("invalid Unicode string");
        return value2;
      }
    }
    throw new Error("unterminated string");
  };
  const scan = (depth) => {
    if (depth > 100) throw new Error("JSON nesting limit");
    ws();
    if (text[i] === '"') {
      str();
      return;
    }
    if (text[i] === "{") {
      i++;
      ws();
      const keys = /* @__PURE__ */ new Set();
      if (text[i] === "}") {
        i++;
        return;
      }
      for (; ; ) {
        ws();
        const key = str();
        if (keys.has(key)) throw new Error("duplicate JSON key");
        keys.add(key);
        ws();
        i++;
        scan(depth + 1);
        ws();
        if (text[i++] === "}") return;
      }
    }
    if (text[i] === "[") {
      i++;
      ws();
      if (text[i] === "]") {
        i++;
        return;
      }
      for (; ; ) {
        scan(depth + 1);
        ws();
        if (text[i++] === "]") return;
      }
    }
    while (i < text.length && !/[\s,\]}]/.test(text[i])) i++;
  };
  scan(0);
  return value;
}

// apps/extension/settings.mjs
var DEFAULT_SETTINGS = Object.freeze({
  ensRootName: "bound-v2.eth",
  ensResolver: "0xf6efa18d24c108a060b0d2a0e715b9045e09ea0f",
  arkivRpcUrl: "https://rpc.rabdi.db-chain.testnet.arkiv.network",
  watcherOwner: "0xE63393558E36dF643347326E7e03AD5fB0E6c867",
  safePageUrl: "https://bzz.limo/bzz/2ef102c267b6d62900b8c31c25620405d5fff12e22cd01f79038bd3eea0e682c/",
  watcherUrl: "https://bound-aggregator-0-1-1.onrender.com/v1/observations",
  anonBootstrapUrl: "https://ethereum-sepolia-rpc.publicnode.com",
  anonRpcUrl: "https://ethereum-sepolia-rpc.publicnode.com"
});
var URL_FIELDS = ["ensRpcUrl", "arkivRpcUrl", "watcherUrl", "anonBootstrapUrl", "anonRpcUrl", "safePageUrl"];
function cleanUrl(value, { local = false } = {}) {
  if (value === "") return "";
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid endpoint URL.");
  }
  if (url.protocol !== "https:" && !(local && url.protocol === "http:" && ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)) || url.username || url.password || url.search || url.hash) throw new Error("Endpoints must use HTTPS without credentials or query parameters.");
  return url.toString();
}
function normalizeSettings(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Invalid settings.");
  const settings = { network: "sepolia", ensChainId: 11155111, arkivChainId: 7794095, anonWorkerId: "nox" };
  for (const name of URL_FIELDS) {
    if (input[name] !== void 0 && typeof input[name] !== "string") throw new Error("Invalid endpoint.");
    settings[name] = cleanUrl((input[name] ?? "").trim(), { local: name === "watcherUrl" || name === "safePageUrl" });
  }
  if (settings.watcherUrl && new URL(settings.watcherUrl).pathname !== "/v1/observations") throw new Error("The watcher URL must end with /v1/observations.");
  for (const name of ["ensResolver", "watcherOwner"]) {
    if (input[name] !== void 0 && typeof input[name] !== "string") throw new Error("Invalid address.");
    const value = (input[name] ?? "").trim().toLowerCase();
    if (value && !/^0x[0-9a-f]{40}$/.test(value)) throw new Error("Enter a valid 20-byte address.");
    settings[name] = value;
  }
  if (input.ensRootName !== void 0 && typeof input.ensRootName !== "string") throw new Error("Invalid ENS root name.");
  const root = (input.ensRootName ?? "").trim().toLowerCase();
  if (root && !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9-]+$/.test(root)) throw new Error("Enter a valid ENS root name.");
  settings.ensRootName = root;
  const gateways = Array.isArray(input.swarmGateways) ? input.swarmGateways : typeof input.swarmGateways === "string" ? input.swarmGateways.split(/\r?\n/) : [];
  if (gateways.some((value) => typeof value !== "string")) throw new Error("Invalid Swarm gateway.");
  settings.swarmGateways = gateways.map((value) => cleanUrl(value.trim())).filter(Boolean);
  if (settings.swarmGateways.length > 8 || new Set(settings.swarmGateways.map((value) => new URL(value).origin)).size !== settings.swarmGateways.length) throw new Error("Swarm gateways must have distinct origins.");
  return settings;
}

// apps/extension/arkiv-reader.mjs
var ADDRESS = /^0x[0-9a-f]{40}$/;
var KEY = /^0x[0-9a-f]{64}$/;
var QUANTITY = /^0x(?:0|[1-9a-f][0-9a-f]*)$/;
var CACHE_MS = 5 * 6e4;
var DECISION_MS = 3e4;
var ENS_BUNDLE_MS = 60 * 6e4;
var ENS_RECORD_MS = 24 * 60 * 6e4;
var LIMIT = 32;
var MAX_PAGES = 256;
var MAX_RESPONSE = 1e6;
function quantity(value) {
  if (typeof value !== "string" || !QUANTITY.test(value)) throw new Error("Invalid Arkiv quantity");
  const n = Number(BigInt(value));
  if (!Number.isSafeInteger(n)) throw new Error("Invalid Arkiv quantity");
  return n;
}
function decode(attributes) {
  if (!Array.isArray(attributes)) throw new Error("Invalid Arkiv attributes");
  const tag = attributes.filter((item) => item?.name === "arkiv.schema"), payload = attributes.filter((item) => item?.name === "payload");
  if (tag.length !== 1 || tag[0].type !== "str" || tag[0].value !== "bound.record.v1" || payload.length !== 1 || payload[0].type !== "bytes" || typeof payload[0].value !== "string" || !/^0x(?:[0-9a-f]{2})*$/.test(payload[0].value) || payload[0].value.length > 262146) throw new Error("Invalid Arkiv payload");
  const hex = payload[0].value.slice(2), bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  const record = parseUniqueJSON(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  if (!validateRecord(record)) throw new Error("Invalid Arkiv record");
  return record;
}
async function boundedText(response, budget) {
  if (!response.ok) throw new Error("Arkiv unavailable");
  const declared = response.headers?.get?.("content-length");
  if (declared !== null && declared !== void 0 && (!/^\d+$/.test(declared) || Number(declared) > MAX_RESPONSE)) throw new Error("Arkiv response too large");
  if (!response.body?.getReader) {
    const text = await response.text();
    const size2 = new TextEncoder().encode(text).length;
    if (size2 > MAX_RESPONSE || budget && (budget.bytes += size2) > 8e6) throw new Error("Arkiv response too large");
    return text;
  }
  const reader = response.body.getReader(), parts = [];
  let size = 0;
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!(value instanceof Uint8Array) || (size += value.length) > MAX_RESPONSE) {
        await reader.cancel();
        throw new Error("Arkiv response too large");
      }
      parts.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  if (budget && (budget.bytes += size) > 8e6) throw new Error("Arkiv response too large");
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    bytes.set(part, offset);
    offset += part.length;
  }
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}
function checkedSettings(input) {
  const settings = normalizeSettings(input);
  if (!settings.arkivRpcUrl || !ADDRESS.test(settings.watcherOwner)) throw new Error("Arkiv settings incomplete");
  return settings;
}
var READ_KINDS = ["baseline", "status", "drift", "ens_record", "frontend", "incident"];
var KIND_FILTER = `(${READ_KINDS.map((kind) => `kind = str('${kind}')`).join(" OR ")})`;
async function queryAll(request, owner, limits = { pages: 0, restarts: 0 }) {
  let cursor = null, block = null;
  const records = [];
  while (limits.pages++ < MAX_PAGES) {
    const expression = `$owner = addr(${owner}) AND arkiv.schema = str('bound.record.v1') AND ${KIND_FILTER}${cursor ? ` AND $key > key(${cursor})` : ""} ORDER BY $key ASC`;
    const result = await request("arkiv_query", [expression, { select: { key: true, owner: true, expiresAt: true, attributes: true }, limit: `0x${LIMIT.toString(16)}` }]);
    if (!result || !Array.isArray(result.data) || result.data.length > LIMIT) throw new Error("Invalid Arkiv query");
    const current = quantity(result.blockNumber);
    if (block !== null && block !== current) {
      if (limits.restarts++ === 0) return queryAll(request, owner, limits);
      throw new Error("Arkiv pagination changed block");
    }
    block = current;
    for (const row of result.data) {
      if (!row || typeof row.key !== "string" || !KEY.test(row.key) || cursor && row.key <= cursor) throw new Error("Invalid Arkiv pagination");
      cursor = row.key;
      if (typeof row.owner !== "string" || !ADDRESS.test(row.owner)) throw new Error("Invalid Arkiv owner");
      if (row.owner !== owner) continue;
      const expiresAt = quantity(row.expiresAt);
      if (expiresAt <= block) continue;
      const record = decode(row.attributes);
      if (READ_KINDS.includes(record.kind)) records.push({ key: row.key, owner: row.owner, expiresAt, record });
    }
    if (result.data.length < LIMIT) return { records, block };
  }
  throw new Error("Arkiv pagination limit reached");
}
function mapRecords(cache, currentBlock, time) {
  const freshUntil = Math.min(cache.fetchedAt + CACHE_MS, time + DECISION_MS), expiresAt = new Date(freshUntil).toISOString(), output = [];
  const eligible = cache.records.filter((entry) => entry.owner === cache.owner && KEY.test(entry.key) && Number.isSafeInteger(entry.expiresAt) && entry.expiresAt > currentBlock && validateRecord(entry.record));
  for (const entry of eligible) {
    const record = entry.record, common = { owner: entry.owner, site: record.site, chain: String(record.chainId), expiresAt };
    if (record.kind === "baseline") output.push({ ...common, kind: "baseline", observed: [.../* @__PURE__ */ new Set([...record.counterparties, ...record.calledContracts])].sort(), witnessed: [] });
    else if (record.kind === "status") {
      output.push({ ...common, kind: "status", status: record.state === "incident" ? "active" : record.state === "normal" ? "normal" : "drift" });
      if (record.state === "drift") {
        const evidence = eligible.filter((item) => item.record.kind === "drift" && item.record.site === record.site && item.record.chainId === record.chainId && item.record.detectedAt === record.updatedAt);
        if (evidence.length === 1 && evidence[0].record.corroborated === true) output.push({ ...common, kind: "drift", corroborated: true, active: true });
      }
    }
  }
  return output;
}
function createArkivReader({ getSettings, storage, anonymousRequest, fetchImpl = fetch, now = Date.now }) {
  if (typeof getSettings !== "function" || !storage || typeof storage.get !== "function" || typeof storage.set !== "function" || typeof anonymousRequest !== "function" || typeof fetchImpl !== "function") throw new Error("Invalid Arkiv reader");
  async function directRequest(settings, method, params, signal, budget) {
    const response = await fetchImpl(settings.arkivRpcUrl, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }), credentials: "omit", redirect: "error", signal });
    const body = parseUniqueJSON(await boundedText(response, budget));
    if (!body || body.jsonrpc !== "2.0" || body.id !== 1 || Object.hasOwn(body, "error") || !Object.hasOwn(body, "result")) throw new Error("Invalid Arkiv RPC response");
    return body.result;
  }
  async function anon(method, params) {
    const response = await anonymousRequest({ network: "arkiv", method, params });
    if (!response || Object.hasOwn(response, "error") || !Object.hasOwn(response, "result")) throw new Error("Anonymized Arkiv unavailable");
    return response.result;
  }
  const flights = /* @__PURE__ */ new Map();
  const keyOf = (s) => JSON.stringify([s.arkivRpcUrl, s.arkivChainId, s.watcherOwner]);
  function refresh() {
    const flight = (async () => {
      const settings = checkedSettings(await getSettings()), key = keyOf(settings);
      const existing = flights.get(key);
      if (existing && existing !== flight) return existing;
      flights.set(key, flight);
      const controller = new AbortController(), budget = { bytes: 0 };
      let timer;
      const deadline = new Promise((_, reject) => {
        timer = setTimeout(() => {
          controller.abort();
          reject(new Error("Arkiv refresh deadline exceeded"));
        }, 3e4);
      });
      let result;
      try {
        result = await Promise.race([(async () => {
          if (quantity(await directRequest(settings, "eth_chainId", [], controller.signal, budget)) !== settings.arkivChainId) throw new Error("Unexpected Arkiv chain");
          return queryAll((method, params) => directRequest(settings, method, params, controller.signal, budget), settings.watcherOwner);
        })(), deadline]);
      } finally {
        clearTimeout(timer);
      }
      const time = now();
      if (!Number.isSafeInteger(time) || time < 0) throw new Error("Invalid cache clock");
      if (keyOf(checkedSettings(await getSettings())) !== key) throw new Error("Arkiv settings changed");
      const previous = (await storage.get("boundWatcherBundle")).boundWatcherBundle, watermarks = (await storage.get("boundWatcherBlockWatermarks")).boundWatcherBlockWatermarks;
      const watermark = watermarks?.[key];
      if (Number.isSafeInteger(watermark) && result.block < watermark || previous?.version === 2 && previous.owner === settings.watcherOwner && previous.url === settings.arkivRpcUrl && previous.chainId === settings.arkivChainId && Number.isSafeInteger(previous.verifiedAt) && Number.isSafeInteger(previous.block) && result.block < previous.block) throw new Error("Arkiv block moved backwards");
      const bundle = { version: 2, owner: settings.watcherOwner, url: settings.arkivRpcUrl, chainId: settings.arkivChainId, fetchedAt: time, verifiedAt: null, ...result };
      const retain = previous?.version === 2 && previous.owner === settings.watcherOwner && previous.url === settings.arkivRpcUrl && previous.chainId === settings.arkivChainId && Number.isSafeInteger(previous.verifiedAt);
      await storage.set(retain ? { boundWatcherPendingBundle: bundle } : { boundWatcherBundle: bundle, boundWatcherPendingBundle: null });
      return { ok: true, fetchedAt: time };
    })();
    flight.finally(() => {
      for (const [key, value] of flights) if (value === flight) flights.delete(key);
    }).catch(() => {
    });
    return flight;
  }
  let watermarkWrite = Promise.resolve();
  async function observeBlock(settings, block) {
    const key = keyOf(settings);
    const operation = watermarkWrite.then(async () => {
      const watermarks = (await storage.get("boundWatcherBlockWatermarks")).boundWatcherBlockWatermarks || {};
      if (Number.isSafeInteger(watermarks[key]) && block < watermarks[key]) throw new Error("Arkiv block moved backwards");
      if (keyOf(checkedSettings(await getSettings())) !== key) throw new Error("Arkiv settings changed");
      await storage.set({ boundWatcherBlockWatermarks: { ...watermarks, [key]: block } });
    });
    watermarkWrite = operation.catch(() => {
    });
    await operation;
    return block;
  }
  async function currentBlock(settings) {
    const [chain, block] = await Promise.all([anon("eth_chainId", []), anon("eth_blockNumber", [])]);
    if (quantity(chain) !== settings.arkivChainId) throw new Error("Unexpected Arkiv chain");
    return observeBlock(settings, quantity(block));
  }
  let verifyFlight;
  async function verifyBundleBlock() {
    if (verifyFlight) return verifyFlight;
    const flight = (async () => {
      const settings = checkedSettings(await getSettings()), key = keyOf(settings), pending = (await storage.get("boundWatcherPendingBundle")).boundWatcherPendingBundle, stored = (await storage.get("boundWatcherBundle")).boundWatcherBundle, time = now();
      const matches = (c) => c?.version === 2 && c.owner === settings.watcherOwner && c.url === settings.arkivRpcUrl && c.chainId === settings.arkivChainId;
      const cache = matches(pending) ? pending : stored;
      if (!cache || cache.version !== 2 || cache.owner !== settings.watcherOwner || cache.url !== settings.arkivRpcUrl || cache.chainId !== settings.arkivChainId || !Number.isSafeInteger(cache.block)) throw new Error("Watcher bundle unavailable");
      if (Number.isSafeInteger(cache.verifiedAt) && time >= cache.verifiedAt && time - cache.verifiedAt < DECISION_MS) return { block: cache.block, verifiedAt: cache.verifiedAt };
      const watermarks = (await storage.get("boundWatcherBlockWatermarks")).boundWatcherBlockWatermarks || {};
      if (matches(pending) && Number.isSafeInteger(watermarks[key]) && cache.block < watermarks[key]) throw new Error("Arkiv verification superseded");
      const block = await currentBlock(settings), verifiedAt = now();
      if (block < cache.block || keyOf(checkedSettings(await getSettings())) !== key) throw new Error("Arkiv verification superseded");
      const latest = (await storage.get(matches(pending) ? "boundWatcherPendingBundle" : "boundWatcherBundle"))[matches(pending) ? "boundWatcherPendingBundle" : "boundWatcherBundle"];
      if (JSON.stringify(latest) !== JSON.stringify(cache)) throw new Error("Arkiv bundle changed");
      await storage.set({ boundWatcherBundle: { ...cache, block, verifiedAt }, boundWatcherPendingBundle: null });
      return { block, verifiedAt };
    })();
    verifyFlight = flight;
    try {
      return await flight;
    } finally {
      if (verifyFlight === flight) verifyFlight = null;
    }
  }
  const unavailable = () => ({ state: "unavailable", fetchedAt: null, ageMs: null, verifiedAt: null, block: null, frontend: null, rawDrift: false, corroboratedDrift: false, activeIncident: false, ambiguous: false, communityReportingSafe: false });
  async function readCommunityCache({ site, chain, now: requestedTime }) {
    const time = requestedTime === void 0 ? now() : requestedTime;
    try {
      const settings = checkedSettings(await getSettings()), cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle;
      if (!Number.isSafeInteger(time) || !cache || cache.version !== 2 || cache.owner !== settings.watcherOwner || cache.url !== settings.arkivRpcUrl || cache.chainId !== settings.arkivChainId || !Number.isSafeInteger(cache.fetchedAt) || cache.fetchedAt > time || time - cache.fetchedAt >= ENS_BUNDLE_MS || !Number.isSafeInteger(cache.block) || !Array.isArray(cache.records)) return unavailable();
      const ageMs = time - cache.fetchedAt, verified = Number.isSafeInteger(cache.verifiedAt) && cache.verifiedAt <= time && time - cache.verifiedAt < DECISION_MS;
      if (!Number.isSafeInteger(cache.verifiedAt) || cache.verifiedAt < 0 || cache.verifiedAt > time || ageMs < CACHE_MS && !verified) return unavailable();
      const watermarks = (await storage.get("boundWatcherBlockWatermarks")).boundWatcherBlockWatermarks || {}, block = Math.max(cache.block, watermarks[keyOf(settings)] ?? cache.block);
      const entries = cache.records.filter((e) => e?.owner === cache.owner && KEY.test(e.key) && Number.isSafeInteger(e.expiresAt) && e.expiresAt > block && validateRecord(e.record) && (!e.record.updatedAt || Date.parse(e.record.updatedAt) <= time) && (!e.record.detectedAt || Date.parse(e.record.detectedAt) <= time) && (!e.record.createdAt || Date.parse(e.record.createdAt) <= time) && e.record.site === site && String(e.record.chainId) === String(chain));
      const fronts = entries.filter((e) => e.record.kind === "frontend"), statuses = entries.filter((e) => e.record.kind === "status"), drifts = entries.filter((e) => e.record.kind === "drift"), incidents = entries.filter((e) => e.record.kind === "incident");
      const ambiguous = fronts.length !== 1 || statuses.length !== 1, frontend = fronts.length === 1 && Date.parse(fronts[0].record.updatedAt) <= time ? { ...fronts[0].record, scripts: fronts[0].record.scripts.filter((row) => Date.parse(row.lastSeen) <= time && time - Date.parse(row.lastSeen) < 1728e5) } : null, status = statuses.length === 1 ? statuses[0].record : null;
      return { state: ageMs < CACHE_MS ? "fresh" : "stale", fetchedAt: cache.fetchedAt, ageMs, verifiedAt: cache.verifiedAt, block, frontend, rawDrift: statuses.some((e) => e.record.state === "drift"), corroboratedDrift: statuses.length === 1 && status?.state === "drift" && drifts.length === 1 && drifts[0].record.detectedAt === status.updatedAt && drifts[0].record.corroborated === true, activeIncident: statuses.length === 1 && status?.state === "incident" && incidents.length === 1 && status.incidentReference === incidents[0].key, ambiguous, communityReportingSafe: !ambiguous && status?.state === "normal" };
    } catch {
      return unavailable();
    }
  }
  async function ensureCommunity({ site, chain, budgetMs = 1500 }) {
    const before = await readCommunityCache({ site, chain });
    if (before.state === "fresh") return before;
    const work = (async () => {
      const settings = checkedSettings(await getSettings()), cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle, time = now();
      if (cache?.version === 2 && cache.owner === settings.watcherOwner && cache.url === settings.arkivRpcUrl && cache.chainId === settings.arkivChainId && Number.isSafeInteger(cache.fetchedAt) && cache.fetchedAt <= time && time - cache.fetchedAt < CACHE_MS) await verifyBundleBlock();
      else {
        await refresh();
        await verifyBundleBlock();
      }
    })();
    let timer;
    try {
      await Promise.race([work.catch(() => {
      }), new Promise((resolve) => {
        timer = setTimeout(resolve, Math.max(0, budgetMs));
      })]);
    } finally {
      clearTimeout(timer);
    }
    return readCommunityCache({ site, chain });
  }
  async function readWatcherBundle() {
    const settings = checkedSettings(await getSettings()), time = now();
    let cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle;
    if (!cache || cache.version !== 2 || cache.fetchedAt > time || time - cache.fetchedAt >= CACHE_MS) {
      await refresh();
      cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle;
    }
    if (!cache || cache.version !== 2 || cache.chainId !== settings.arkivChainId || cache.owner !== settings.watcherOwner || cache.url !== settings.arkivRpcUrl || !Number.isSafeInteger(cache.fetchedAt) || cache.fetchedAt > time || time - cache.fetchedAt >= CACHE_MS || !Number.isSafeInteger(cache.block) || !Array.isArray(cache.records)) throw new Error("Watcher bundle unavailable or stale");
    await verifyBundleBlock();
    const latest = (await storage.get("boundWatcherBundle")).boundWatcherBundle, watermarks = (await storage.get("boundWatcherBlockWatermarks")).boundWatcherBlockWatermarks || {};
    if (!latest || latest.owner !== settings.watcherOwner || latest.url !== settings.arkivRpcUrl || latest.chainId !== settings.arkivChainId) throw new Error("Watcher bundle changed");
    return mapRecords(latest, Math.max(latest.block, watermarks[keyOf(settings)] ?? latest.block), time);
  }
  const anonOwnerFlights = /* @__PURE__ */ new Map();
  function anonOwnerRecords(settings) {
    const key = JSON.stringify([settings.arkivChainId, settings.watcherOwner]);
    let flight = anonOwnerFlights.get(key);
    if (!flight) {
      flight = (async () => {
        if (quantity(await anon("eth_chainId", [])) !== settings.arkivChainId) throw new Error("Unexpected Arkiv chain");
        const result = await queryAll(anon, settings.watcherOwner);
        await observeBlock(settings, result.block);
        return { result, time: now() };
      })();
      anonOwnerFlights.set(key, flight);
      flight.finally(() => {
        if (anonOwnerFlights.get(key) === flight) anonOwnerFlights.delete(key);
      }).catch(() => {
      });
    }
    return flight;
  }
  async function readSiteStatusViaAnonRpc({ site }) {
    const settings = checkedSettings(await getSettings());
    const { result, time } = await anonOwnerRecords(settings);
    return mapRecords({ owner: settings.watcherOwner, fetchedAt: time, records: result.records }, result.block, time).filter((item) => item.site === site);
  }
  async function readEnsRecord({ site, chain }) {
    const settings = checkedSettings(await getSettings()), cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle, time = now();
    if (!cache || cache.version !== 2 || cache.chainId !== settings.arkivChainId || cache.owner !== settings.watcherOwner || cache.url !== settings.arkivRpcUrl || !Number.isSafeInteger(cache.fetchedAt) || cache.fetchedAt > time || time - cache.fetchedAt >= ENS_BUNDLE_MS || !Number.isSafeInteger(cache.block) || !Array.isArray(cache.records)) return null;
    const watermarks = (await storage.get("boundWatcherBlockWatermarks")).boundWatcherBlockWatermarks || {}, block = Math.max(cache.block, watermarks[keyOf(settings)] ?? cache.block);
    const matches = cache.records.filter((entry) => entry?.owner === cache.owner && KEY.test(entry.key) && Number.isSafeInteger(entry.expiresAt) && entry.expiresAt > block && validateRecord(entry.record) && entry.record.kind === "ens_record" && entry.record.site === site && String(entry.record.chainId) === chain);
    if (matches.length !== 1) return null;
    const record = matches[0].record, resolvedAt = Date.parse(record.resolvedAt);
    if (!Number.isFinite(resolvedAt) || resolvedAt > time || time - resolvedAt >= ENS_RECORD_MS) return null;
    return { owner: matches[0].owner, site: record.site, chain, name: record.name, resolver: record.resolver, records: { ...record.records }, resolvedAt: record.resolvedAt };
  }
  async function readTrustSnapshot({ key, owner }) {
    const settings = checkedSettings(await getSettings());
    if (typeof key !== "string" || !KEY.test(key) || typeof owner !== "string" || !ADDRESS.test(owner)) throw new Error("Invalid ENS Arkiv pointer");
    const block = await currentBlock(settings), row = await anon("arkiv_getEntity", [key]);
    if (!row || row.key !== key || typeof row.owner !== "string" || row.owner.toLowerCase() !== owner) throw new Error("Arkiv snapshot owner mismatch");
    const expiresAt = quantity(row.expiresAt);
    if (expiresAt <= block) throw new Error("Arkiv snapshot entity expired");
    const record = decode(row.attributes);
    if (record.kind !== "trust_snapshot") throw new Error("Arkiv entity is not a trust snapshot");
    return { key, owner, expiresAt, record };
  }
  async function readUncuratedViaAnonRpc({ site, chain }) {
    return (await readSiteStatusViaAnonRpc({ site })).filter((item) => item.chain === chain);
  }
  return { refresh, verifyBundleBlock, readCommunityCache, ensureCommunity, readWatcherBundle, readSiteStatusViaAnonRpc, readUncuratedViaAnonRpc, readEnsRecord, readTrustSnapshot };
}
export {
  createArkivReader
};
