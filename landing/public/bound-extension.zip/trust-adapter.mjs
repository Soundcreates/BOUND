import {anonRpc} from "./anon-rpc-host.mjs";
import {createEnsLookupCache} from "./ens-cache.mjs";
import {createTrustEngine} from "./trust-bundle.js";
import {createArkivReader} from "./arkiv-bundle.js";
// L1 of the ENS lookup cache: in memory, mirrored to chrome.storage.session.
const ensCache=createEnsLookupCache({storage:chrome.storage.session});
let engine,reader;
async function settings(){const {boundSettings}=await chrome.storage.local.get("boundSettings");return boundSettings;}
async function trustEngine(){
 if(!engine)engine=createTrustEngine({getSettings:settings,storage:chrome.storage.local,anonymousRequest:anonRpc,readArkivSnapshot:async query=>(await arkivReader()).readTrustSnapshot(query),ensCache,readEnsRecord:async query=>(await arkivReader()).readEnsRecord(query)});
 return engine;
}
async function arkivReader(){
 if(!reader)reader=createArkivReader({getSettings:settings,storage:chrome.storage.local,anonymousRequest:anonRpc});
 return reader;
}
export async function getWatcherOwner(){
 const {boundSettings}=await chrome.storage.local.get("boundSettings");const owner=boundSettings?.watcherOwner;
 return typeof owner==="string"&&/^0x[0-9a-f]{40}$/.test(owner)?owner:null;
}
export const decisionAdapters={
 async readVerifiedSnapshot(){return (await trustEngine()).readVerifiedSnapshot();},
 async readProtocolAttestationsViaAnonRpc(query){return (await trustEngine()).readProtocolAttestationsViaAnonRpc(query);},
 async readProtocolAttestations(query){return (await trustEngine()).readProtocolAttestations(query);},
 async readWatcherBundle(){return (await arkivReader()).readWatcherBundle();},
 async readSiteStatusViaAnonRpc(query){return (await arkivReader()).readSiteStatusViaAnonRpc(query);},
 async readUncuratedViaAnonRpc(query){return (await arkivReader()).readUncuratedViaAnonRpc(query);},
 async refresh(){await Promise.allSettled([trustEngine().then(value=>value.readVerifiedSnapshot()),arkivReader().then(value=>value.refresh())]);}
};
