// packages/contracts/index.js
var ADDRESS_RE = /^0x[0-9a-f]{40}$/;
var DIGEST_RE = /^0x[0-9a-f]{64}$/;
var ARKIV_ENTITY_REFERENCE_RE = /^[0-9a-f]{64}$/;
var integer = (n) => Number.isSafeInteger(n) && n >= 0;
var wellFormed = (s) => {
  for (let i = 0; i < s.length; i++) {
    const unit = s.charCodeAt(i);
    if (unit >= 55296 && unit <= 56319) {
      const next = s.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343)) return false;
    } else if (unit >= 56320 && unit <= 57343) return false;
  }
  return true;
};
var nonempty = (s) => typeof s === "string" && s.length > 0 && wellFormed(s);
var isAddress = (v) => typeof v === "string" && ADDRESS_RE.test(v);
var isDigest = (v) => typeof v === "string" && DIGEST_RE.test(v);
var isArkivEntityReference = (v) => typeof v === "string" && ARKIV_ENTITY_REFERENCE_RE.test(v);
var exact = (v, keys) => v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every((k) => Object.hasOwn(v, k));
var host = (s) => {
  if (!nonempty(s)) return false;
  try {
    const u = new URL("https://" + s);
    return u.host === s && u.pathname === "/" && !u.username && !u.password && !u.search && !u.hash;
  } catch {
    return false;
  }
};
var network = (v) => typeof v === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/.test(v);
var timestamp = (s) => {
  if (typeof s !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(s)) return false;
  const date = new Date(s);
  if (Number.isNaN(date.getTime())) return false;
  const canonical = date.toISOString();
  return s === canonical || s === canonical.replace(".000Z", "Z");
};
var sortedUnique = (xs, predicate) => Array.isArray(xs) && xs.every((x, i) => predicate(x) && (i === 0 || xs[i - 1] < x));
var addresses = (xs) => sortedUnique(xs, isAddress);
var READ_ONLY_METHODS = Object.freeze(["eth_accounts", "eth_chainId", "eth_blockNumber", "eth_call", "eth_getBalance", "eth_getCode", "eth_getTransactionCount", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockByNumber", "eth_getBlockByHash", "eth_getLogs", "net_version"]);
var ALREADY_SIGNED_METHODS = Object.freeze(["eth_sendRawTransaction"]);
var ENS_CACHE_KEYS = Object.freeze(["bound.attest.v1", "bound.frontend.v1"]);
var ENS_CACHE_VALUE_MAX = 16384;
var ensName = (s) => nonempty(s) && s.length <= 255 && /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(s);
var baseRecord = (v, keys) => exact(v, ["schemaVersion", "kind", "site", "chainId", ...keys]) && v.schemaVersion === 1 && host(v.site) && integer(v.chainId) && v.chainId > 0;
var change = (v) => exact(v, ["kind", "before", "after"]) && ["ns", "cert", "a-record"].includes(v.kind) && sortedUnique(v.before, nonempty) && v.before.length > 0 && sortedUnique(v.after, nonempty) && v.after.length > 0 && JSON.stringify(v.before) !== JSON.stringify(v.after);
function validateRecord(v) {
  if (v === null || typeof v !== "object" || Array.isArray(v)) return false;
  switch (v.kind) {
    case "observation":
      return baseRecord(v, ["value", "reporterKey", "event"]) && isAddress(v.value) && nonempty(v.reporterKey) && ["counterparty", "called-contract", "warned"].includes(v.event);
    case "baseline":
      return baseRecord(v, ["counterparties", "calledContracts", "updatedAt"]) && addresses(v.counterparties) && addresses(v.calledContracts) && timestamp(v.updatedAt);
    case "drift":
      return baseRecord(v, ["changes", "corroborated", "evidenceReference", "detectedAt"]) && Array.isArray(v.changes) && v.changes.length > 0 && v.changes.every((item, i) => change(item) && (!i || v.changes[i - 1].kind < item.kind)) && typeof v.corroborated === "boolean" && isArkivEntityReference(v.evidenceReference) && timestamp(v.detectedAt);
    case "incident":
      return baseRecord(v, ["trigger", "severity", "counterparty", "reportDigest", "reportReference", "createdAt"]) && ["drift+warned", "K-same-counterparty-warned"].includes(v.trigger) && v.severity === "high" && isAddress(v.counterparty) && isDigest(v.reportDigest) && /^[0-9a-f]{64}$/.test(v.reportReference) && timestamp(v.createdAt);
    case "evidence":
      return baseRecord(v, ["digest", "payload", "createdAt"]) && isDigest(v.digest) && typeof v.payload === "string" && v.payload.length > 0 && new TextEncoder().encode(v.payload).length <= 61440 && timestamp(v.createdAt);
    case "trust_snapshot":
      return exact(v, ["schemaVersion", "kind", "network", "epoch", "digest", "canonical"]) && v.schemaVersion === 1 && network(v.network) && integer(v.epoch) && v.epoch > 0 && isDigest(v.digest) && typeof v.canonical === "string" && v.canonical.length > 0 && new TextEncoder().encode(v.canonical).length <= 61440;
    case "status":
      return baseRecord(v, ["state", "feedReference", "incidentReference", "updatedAt"]) && ["normal", "drift", "incident"].includes(v.state) && isDigest(v.feedReference) && (v.state === "incident" ? v.incidentReference === null || isDigest(v.incidentReference) : v.incidentReference === null) && timestamp(v.updatedAt);
    // Watcher-asserted copy of ENS text records for one curated site. It is a
    // cache for availability and display only; it never establishes trust.
    case "ens_record":
      return baseRecord(v, ["name", "resolver", "records", "resolvedAt"]) && ensName(v.name) && isAddress(v.resolver) && timestamp(v.resolvedAt) && v.records !== null && typeof v.records === "object" && !Array.isArray(v.records) && Object.keys(v.records).length > 0 && Object.entries(v.records).every(([k, text]) => ENS_CACHE_KEYS.includes(k) && typeof text === "string" && text.length <= ENS_CACHE_VALUE_MAX && wellFormed(text));
    default:
      return false;
  }
}
function parseUniqueJSON(text) {
  if (typeof text !== "string" || text.length > 1e6) throw new Error("invalid JSON size");
  const value = JSON.parse(text);
  let i = 0;
  const ws = () => {
    while (i < text.length && /\s/.test(text[i])) i++;
  };
  const str = () => {
    const start = i++;
    while (i < text.length) {
      if (text[i] === "\\") {
        i += 2;
        continue;
      }
      if (text[i++] === '"') {
        const value2 = JSON.parse(text.slice(start, i));
        if (!wellFormed(value2)) throw new Error("invalid Unicode string");
        return value2;
      }
    }
    throw new Error("unterminated string");
  };
  const scan = (depth) => {
    if (depth > 100) throw new Error("JSON nesting limit");
    ws();
    if (text[i] === '"') {
      str();
      return;
    }
    if (text[i] === "{") {
      i++;
      ws();
      const keys = /* @__PURE__ */ new Set();
      if (text[i] === "}") {
        i++;
        return;
      }
      for (; ; ) {
        ws();
        const key = str();
        if (keys.has(key)) throw new Error("duplicate JSON key");
        keys.add(key);
        ws();
        i++;
        scan(depth + 1);
        ws();
        if (text[i++] === "}") return;
      }
    }
    if (text[i] === "[") {
      i++;
      ws();
      if (text[i] === "]") {
        i++;
        return;
      }
      for (; ; ) {
        scan(depth + 1);
        ws();
        if (text[i++] === "]") return;
      }
    }
    while (i < text.length && !/[\s,\]}]/.test(text[i])) i++;
  };
  scan(0);
  return value;
}

// apps/extension/settings.mjs
var DEFAULT_SETTINGS = Object.freeze({
  ensRootName: "bound-v2.eth",
  ensResolver: "0xf6efa18d24c108a060b0d2a0e715b9045e09ea0f",
  arkivRpcUrl: "https://rpc.rabdi.db-chain.testnet.arkiv.network",
  watcherOwner: "0xE63393558E36dF643347326E7e03AD5fB0E6c867",
  watcherUrl: "http://127.0.0.1:8787/v1/observations",
  anonBootstrapUrl: "https://ethereum-sepolia-rpc.publicnode.com",
  anonRpcUrl: "https://ethereum-sepolia-rpc.publicnode.com"
});
var URL_FIELDS = ["arkivRpcUrl", "watcherUrl", "anonBootstrapUrl", "anonRpcUrl"];
function cleanUrl(value, { local = false } = {}) {
  if (value === "") return "";
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid endpoint URL.");
  }
  if (url.protocol !== "https:" && !(local && url.protocol === "http:" && ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)) || url.username || url.password || url.search || url.hash) throw new Error("Endpoints must use HTTPS without credentials or query parameters.");
  return url.toString();
}
function normalizeSettings(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Invalid settings.");
  const settings = { network: "sepolia", ensChainId: 11155111, arkivChainId: 7794095, anonWorkerId: "nox" };
  for (const name of URL_FIELDS) {
    if (input[name] !== void 0 && typeof input[name] !== "string") throw new Error("Invalid endpoint.");
    settings[name] = cleanUrl((input[name] ?? "").trim(), { local: name === "watcherUrl" });
  }
  if (settings.watcherUrl && new URL(settings.watcherUrl).pathname !== "/v1/observations") throw new Error("The watcher URL must end with /v1/observations.");
  for (const name of ["ensResolver", "watcherOwner"]) {
    if (input[name] !== void 0 && typeof input[name] !== "string") throw new Error("Invalid address.");
    const value = (input[name] ?? "").trim().toLowerCase();
    if (value && !/^0x[0-9a-f]{40}$/.test(value)) throw new Error("Enter a valid 20-byte address.");
    settings[name] = value;
  }
  if (input.ensRootName !== void 0 && typeof input.ensRootName !== "string") throw new Error("Invalid ENS root name.");
  const root = (input.ensRootName ?? "").trim().toLowerCase();
  if (root && !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9-]+$/.test(root)) throw new Error("Enter a valid ENS root name.");
  settings.ensRootName = root;
  return settings;
}

// apps/extension/arkiv-reader.mjs
var ADDRESS = /^0x[0-9a-f]{40}$/;
var KEY = /^0x[0-9a-f]{64}$/;
var QUANTITY = /^0x(?:0|[1-9a-f][0-9a-f]*)$/;
var CACHE_MS = 5 * 6e4;
var DECISION_MS = 3e4;
var ENS_BUNDLE_MS = 60 * 6e4;
var ENS_RECORD_MS = 24 * 60 * 6e4;
var LIMIT = 32;
var MAX_PAGES = 1e3;
var MAX_RESPONSE = 1e6;
function quantity(value) {
  if (typeof value !== "string" || !QUANTITY.test(value)) throw new Error("Invalid Arkiv quantity");
  const n = Number(BigInt(value));
  if (!Number.isSafeInteger(n)) throw new Error("Invalid Arkiv quantity");
  return n;
}
function decode(attributes) {
  if (!Array.isArray(attributes)) throw new Error("Invalid Arkiv attributes");
  const tag = attributes.filter((item) => item?.name === "arkiv.schema"), payload = attributes.filter((item) => item?.name === "payload");
  if (tag.length !== 1 || tag[0].type !== "str" || tag[0].value !== "bound.record.v1" || payload.length !== 1 || payload[0].type !== "bytes" || typeof payload[0].value !== "string" || !/^0x(?:[0-9a-f]{2})*$/.test(payload[0].value) || payload[0].value.length > 262146) throw new Error("Invalid Arkiv payload");
  const hex = payload[0].value.slice(2), bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  const record = parseUniqueJSON(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  if (!validateRecord(record)) throw new Error("Invalid Arkiv record");
  return record;
}
async function boundedText(response) {
  if (!response.ok) throw new Error("Arkiv unavailable");
  const declared = response.headers?.get?.("content-length");
  if (declared !== null && declared !== void 0 && (!/^\d+$/.test(declared) || Number(declared) > MAX_RESPONSE)) throw new Error("Arkiv response too large");
  if (!response.body?.getReader) {
    const text = await response.text();
    if (text.length > MAX_RESPONSE) throw new Error("Arkiv response too large");
    return text;
  }
  const reader = response.body.getReader(), parts = [];
  let size = 0;
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!(value instanceof Uint8Array) || (size += value.length) > MAX_RESPONSE) {
        await reader.cancel();
        throw new Error("Arkiv response too large");
      }
      parts.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    bytes.set(part, offset);
    offset += part.length;
  }
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}
function checkedSettings(input) {
  const settings = normalizeSettings(input);
  if (!settings.arkivRpcUrl || !ADDRESS.test(settings.watcherOwner)) throw new Error("Arkiv settings incomplete");
  return settings;
}
async function queryAll(request, owner) {
  let cursor = null, block = null;
  const records = [];
  for (let page = 0; page < MAX_PAGES; page++) {
    const expression = `$owner = addr(${owner}) AND arkiv.schema = str('bound.record.v1')${cursor ? ` AND $key > key(${cursor})` : ""} ORDER BY $key ASC`;
    const result = await request("arkiv_query", [expression, { select: { key: true, owner: true, expiresAt: true, attributes: true }, limit: `0x${LIMIT.toString(16)}` }]);
    if (!result || !Array.isArray(result.data) || result.data.length > LIMIT) throw new Error("Invalid Arkiv query");
    const current = quantity(result.blockNumber);
    if (block !== null && block !== current) throw new Error("Arkiv pagination changed block");
    block = current;
    for (const row of result.data) {
      if (!row || typeof row.key !== "string" || !KEY.test(row.key) || cursor && row.key <= cursor) throw new Error("Invalid Arkiv pagination");
      cursor = row.key;
      if (typeof row.owner !== "string" || !ADDRESS.test(row.owner)) throw new Error("Invalid Arkiv owner");
      if (row.owner !== owner) continue;
      const expiresAt = quantity(row.expiresAt);
      if (expiresAt <= block) continue;
      const record = decode(row.attributes);
      if (["baseline", "status", "drift", "ens_record"].includes(record.kind)) records.push({ key: row.key, owner: row.owner, expiresAt, record });
    }
    if (result.data.length < LIMIT) return { records, block };
  }
  throw new Error("Arkiv pagination limit reached");
}
function mapRecords(cache, currentBlock, time) {
  const freshUntil = Math.min(cache.fetchedAt + CACHE_MS, time + DECISION_MS), expiresAt = new Date(freshUntil).toISOString(), output = [];
  const eligible = cache.records.filter((entry) => entry.owner === cache.owner && KEY.test(entry.key) && Number.isSafeInteger(entry.expiresAt) && entry.expiresAt > currentBlock && validateRecord(entry.record));
  for (const entry of eligible) {
    const record = entry.record, common = { owner: entry.owner, site: record.site, chain: String(record.chainId), expiresAt };
    if (record.kind === "baseline") output.push({ ...common, kind: "baseline", observed: [.../* @__PURE__ */ new Set([...record.counterparties, ...record.calledContracts])].sort(), witnessed: [] });
    else if (record.kind === "status") {
      output.push({ ...common, kind: "status", status: record.state === "incident" ? "active" : record.state === "normal" ? "normal" : "drift" });
      if (record.state === "drift") {
        const evidence = eligible.filter((item) => item.record.kind === "drift" && item.record.site === record.site && item.record.chainId === record.chainId && item.record.detectedAt === record.updatedAt);
        if (evidence.length === 1 && evidence[0].record.corroborated === true) output.push({ ...common, kind: "drift", corroborated: true, active: true });
      }
    }
  }
  return output;
}
function createArkivReader({ getSettings, storage, anonymousRequest, fetchImpl = fetch, now = Date.now }) {
  if (typeof getSettings !== "function" || !storage || typeof storage.get !== "function" || typeof storage.set !== "function" || typeof anonymousRequest !== "function" || typeof fetchImpl !== "function") throw new Error("Invalid Arkiv reader");
  async function directRequest(settings, method, params) {
    const response = await fetchImpl(settings.arkivRpcUrl, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }), credentials: "omit", redirect: "error", signal: AbortSignal.timeout(5e3) });
    const body = parseUniqueJSON(await boundedText(response));
    if (!body || body.jsonrpc !== "2.0" || body.id !== 1 || Object.hasOwn(body, "error") || !Object.hasOwn(body, "result")) throw new Error("Invalid Arkiv RPC response");
    return body.result;
  }
  async function anon(method, params) {
    const response = await anonymousRequest({ network: "arkiv", method, params });
    if (!response || Object.hasOwn(response, "error") || !Object.hasOwn(response, "result")) throw new Error("Anonymized Arkiv unavailable");
    return response.result;
  }
  async function refresh() {
    const settings = checkedSettings(await getSettings());
    if (quantity(await directRequest(settings, "eth_chainId", [])) !== settings.arkivChainId) throw new Error("Unexpected Arkiv chain");
    const result = await queryAll((method, params) => directRequest(settings, method, params), settings.watcherOwner), time = now();
    if (!Number.isSafeInteger(time) || time < 0) throw new Error("Invalid cache clock");
    await storage.set({ boundWatcherBundle: { version: 1, owner: settings.watcherOwner, url: settings.arkivRpcUrl, fetchedAt: time, ...result } });
  }
  async function currentBlock(settings) {
    const [chain, block] = await Promise.all([anon("eth_chainId", []), anon("eth_blockNumber", [])]);
    if (quantity(chain) !== settings.arkivChainId) throw new Error("Unexpected Arkiv chain");
    return quantity(block);
  }
  async function readWatcherBundle() {
    const settings = checkedSettings(await getSettings()), cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle, time = now();
    if (!cache || cache.version !== 1 || cache.owner !== settings.watcherOwner || cache.url !== settings.arkivRpcUrl || !Number.isSafeInteger(cache.fetchedAt) || cache.fetchedAt > time || time - cache.fetchedAt >= CACHE_MS || !Number.isSafeInteger(cache.block) || !Array.isArray(cache.records)) throw new Error("Watcher bundle unavailable or stale");
    const block = await currentBlock(settings);
    if (block < cache.block) throw new Error("Arkiv block moved backwards");
    return mapRecords(cache, block, time);
  }
  async function readSiteStatusViaAnonRpc({ site }) {
    const settings = checkedSettings(await getSettings());
    if (quantity(await anon("eth_chainId", [])) !== settings.arkivChainId) throw new Error("Unexpected Arkiv chain");
    const result = await queryAll(anon, settings.watcherOwner), time = now();
    return mapRecords({ owner: settings.watcherOwner, fetchedAt: time, records: result.records }, result.block, time).filter((item) => item.site === site);
  }
  async function readEnsRecord({ site, chain }) {
    const settings = checkedSettings(await getSettings()), cache = (await storage.get("boundWatcherBundle")).boundWatcherBundle, time = now();
    if (!cache || cache.version !== 1 || cache.owner !== settings.watcherOwner || cache.url !== settings.arkivRpcUrl || !Number.isSafeInteger(cache.fetchedAt) || cache.fetchedAt > time || time - cache.fetchedAt >= ENS_BUNDLE_MS || !Number.isSafeInteger(cache.block) || !Array.isArray(cache.records)) return null;
    const matches = cache.records.filter((entry) => entry?.owner === cache.owner && KEY.test(entry.key) && Number.isSafeInteger(entry.expiresAt) && entry.expiresAt > cache.block && validateRecord(entry.record) && entry.record.kind === "ens_record" && entry.record.site === site && String(entry.record.chainId) === chain);
    if (matches.length !== 1) return null;
    const record = matches[0].record, resolvedAt = Date.parse(record.resolvedAt);
    if (!Number.isFinite(resolvedAt) || resolvedAt > time || time - resolvedAt >= ENS_RECORD_MS) return null;
    return { owner: matches[0].owner, site: record.site, chain, name: record.name, resolver: record.resolver, records: { ...record.records }, resolvedAt: record.resolvedAt };
  }
  async function readTrustSnapshot({ key, owner }) {
    const settings = checkedSettings(await getSettings());
    if (typeof key !== "string" || !KEY.test(key) || typeof owner !== "string" || !ADDRESS.test(owner)) throw new Error("Invalid ENS Arkiv pointer");
    const block = await currentBlock(settings), row = await anon("arkiv_getEntity", [key]);
    if (!row || row.key !== key || typeof row.owner !== "string" || row.owner.toLowerCase() !== owner) throw new Error("Arkiv snapshot owner mismatch");
    const expiresAt = quantity(row.expiresAt);
    if (expiresAt <= block) throw new Error("Arkiv snapshot entity expired");
    const record = decode(row.attributes);
    if (record.kind !== "trust_snapshot") throw new Error("Arkiv entity is not a trust snapshot");
    return { key, owner, expiresAt, record };
  }
  async function readUncuratedViaAnonRpc({ site, chain }) {
    return (await readSiteStatusViaAnonRpc({ site })).filter((item) => item.chain === chain);
  }
  return { refresh, readWatcherBundle, readSiteStatusViaAnonRpc, readUncuratedViaAnonRpc, readEnsRecord, readTrustSnapshot };
}
export {
  createArkivReader
};
