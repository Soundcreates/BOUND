// packages/contracts/frontend.js
function isFrontendPath(value) {
  if (typeof value !== "string" || !value.startsWith("/") || value.length > 256 || /[^\x20-\x7e]|[?#\\]|%(?:2f|5c)/i.test(value)) return false;
  try {
    if (new URL(value, "https://example.invalid").pathname !== value || value.startsWith("//")) return false;
    return value.split("/").every((segment) => {
      const decoded = decodeURIComponent(segment);
      return decoded.length <= 64 && !/[\x00-\x1f\x7f]/.test(decoded) && !/(?:0x)?[0-9a-f]{40}/i.test(decoded);
    });
  } catch {
    return false;
  }
}
function isFrontendHash(value) {
  if (typeof value !== "string" || !/^sha256-[A-Za-z0-9+/]{43}=$/.test(value)) return false;
  try {
    const raw = atob(value.slice(7));
    return raw.length === 32 && btoa(raw) === value.slice(7);
  } catch {
    return false;
  }
}

// packages/contracts/index.js
var wellFormed = (s) => {
  for (let i = 0; i < s.length; i++) {
    const unit = s.charCodeAt(i);
    if (unit >= 55296 && unit <= 56319) {
      const next = s.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343)) return false;
    } else if (unit >= 56320 && unit <= 57343) return false;
  }
  return true;
};
var READ_ONLY_METHODS = Object.freeze(["eth_accounts", "eth_chainId", "eth_blockNumber", "eth_call", "eth_getBalance", "eth_getCode", "eth_getTransactionCount", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockByNumber", "eth_getBlockByHash", "eth_getLogs", "net_version"]);
var ALREADY_SIGNED_METHODS = Object.freeze(["eth_sendRawTransaction"]);
var ENS_CACHE_KEYS = Object.freeze(["bound.attest.v1", "bound.frontend.v1"]);
function parseUniqueJSON(text) {
  if (typeof text !== "string" || text.length > 1e6) throw new Error("invalid JSON size");
  const value = JSON.parse(text);
  let i = 0;
  const ws = () => {
    while (i < text.length && /\s/.test(text[i])) i++;
  };
  const str = () => {
    const start = i++;
    while (i < text.length) {
      if (text[i] === "\\") {
        i += 2;
        continue;
      }
      if (text[i++] === '"') {
        const value2 = JSON.parse(text.slice(start, i));
        if (!wellFormed(value2)) throw new Error("invalid Unicode string");
        return value2;
      }
    }
    throw new Error("unterminated string");
  };
  const scan = (depth) => {
    if (depth > 100) throw new Error("JSON nesting limit");
    ws();
    if (text[i] === '"') {
      str();
      return;
    }
    if (text[i] === "{") {
      i++;
      ws();
      const keys2 = /* @__PURE__ */ new Set();
      if (text[i] === "}") {
        i++;
        return;
      }
      for (; ; ) {
        ws();
        const key = str();
        if (keys2.has(key)) throw new Error("duplicate JSON key");
        keys2.add(key);
        ws();
        i++;
        scan(depth + 1);
        ws();
        if (text[i++] === "}") return;
      }
    }
    if (text[i] === "[") {
      i++;
      ws();
      if (text[i] === "]") {
        i++;
        return;
      }
      for (; ; ) {
        scan(depth + 1);
        ws();
        if (text[i++] === "]") return;
      }
    }
    while (i < text.length && !/[\s,\]}]/.test(text[i])) i++;
  };
  scan(0);
  return value;
}

// apps/safe-page/src/fragment.mjs
var keys = (v, k) => v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === k.length && k.every((x) => Object.hasOwn(v, x));
var coverage = ["total", "compared", "inlineExcluded", "queryExcluded", "crossOriginExcluded", "privatePathExcluded", "unavailable", "overCap"];
function validSite(s) {
  try {
    const u = new URL("https://" + s);
    return typeof s === "string" && s.length <= 253 && u.host === s && u.pathname === "/" && !u.username && !u.password && !u.search && !u.hash;
  } catch {
    return false;
  }
}
var chain = (s) => typeof s === "string" && /^[1-9][0-9]*$/.test(s) && Number.isSafeInteger(Number(s));
function valid(v) {
  const fields = ["v", "site", "chain", "score", "sev", "reason", "conflicts", "unfamiliar", "cov", "ticket", "watcher"];
  const report = v?.report;
  return (keys(v, fields) || keys(v, [...fields, "report"]) && keys(report, ["time", "method", "checks"]) && Number.isFinite(Date.parse(report.time)) && typeof report.method === "string" && /^[a-zA-Z0-9_]{1,80}$/.test(report.method) && Array.isArray(report.checks) && report.checks.length === 6 && report.checks.every((x) => ["passed", "failed", "unavailable"].includes(x))) && v.v === 1 && validSite(v.site) && chain(v.chain) && (v.score === null || Number.isInteger(v.score) && v.score >= 0 && v.score <= 100) && ["pass", "warning", "huge", "firewall"].includes(v.sev) && Array.isArray(v.reason) && v.reason.length <= 3 && new Set(v.reason).size === v.reason.length && v.reason.every((x) => ["drift", "incident", "counterparty"].includes(x)) && Array.isArray(v.conflicts) && v.conflicts.length <= 16 && v.conflicts.every((x) => keys(x, ["path", "observed", "expected"]) && isFrontendPath(x.path) && isFrontendHash(x.observed) && Array.isArray(x.expected) && x.expected.length <= 4 && x.expected.every(isFrontendHash)) && Array.isArray(v.unfamiliar) && v.unfamiliar.length <= 16 && v.unfamiliar.every((x) => keys(x, ["path", "hash"]) && isFrontendPath(x.path) && isFrontendHash(x.hash)) && keys(v.cov, coverage) && coverage.every((k) => Number.isSafeInteger(v.cov[k]) && v.cov[k] >= 0) && coverage.slice(1).reduce((n, k) => n + v.cov[k], 0) === v.cov.total && typeof v.ticket === "string" && /^[0-9a-f]{32}$/.test(v.ticket) && typeof v.watcher === "string" && /^0x[0-9a-f]{40}$/.test(v.watcher);
}
function parseSafeFragment(hash) {
  try {
    if (typeof hash !== "string" || !hash.startsWith("#") || hash.length > 65536) return null;
    const raw = decodeURIComponent(hash.slice(1));
    if (new TextEncoder().encode(raw).length > 16384) return null;
    const v = parseUniqueJSON(raw);
    return valid(v) ? v : null;
  } catch {
    return null;
  }
}
function encodeSafeFragment(evidence) {
  const v = { ...evidence, conflicts: Array.isArray(evidence?.conflicts) ? evidence.conflicts.slice(0, 16) : evidence?.conflicts, unfamiliar: Array.isArray(evidence?.unfamiliar) ? evidence.unfamiliar.slice(0, 16) : evidence?.unfamiliar };
  if (!valid(v)) throw new Error("Invalid safe evidence");
  let json = JSON.stringify(v);
  while (new TextEncoder().encode(json).length > 16384) {
    if (v.conflicts.length >= v.unfamiliar.length && v.conflicts.length) v.conflicts.pop();
    else if (v.unfamiliar.length) v.unfamiliar.pop();
    else throw new Error("Evidence too large");
    json = JSON.stringify(v);
  }
  const out = "#" + encodeURIComponent(json);
  if (out.length > 65536) throw new Error("Evidence too large");
  return out;
}
export {
  encodeSafeFragment,
  parseSafeFragment,
  validSite
};
