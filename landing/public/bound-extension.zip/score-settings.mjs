// Generated from validated build environment; no secrets are included.
export const SCORE_SETTINGS = {"connectionThreshold":80,"weights":{"origin":10,"snapshot":25,"domain":20,"arkiv":10,"watcher":25,"wallet":10},"transaction":{"green":70,"amber":40,"red":16}};
export const INTAKE_KEY = {"publicKey":"BLmIMZ0Y0Jt335AL2lpfhko9Of7ijvTSt2DR7rGz6ZZWty2fC-l5tQa2xvPDAuY7JdAAHyMHv7psgIksnB5fA54","keyId":"a9c8bf927175e845"};
